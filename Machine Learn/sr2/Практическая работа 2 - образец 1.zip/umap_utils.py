# Утилиты для работы с UMAP и кластеризацией для бинарных данных

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import KMeans, DBSCAN
from sklearn.metrics import silhouette_score
import umap

def optimize_umap_params_for_binary(X, n_neighbors_range=[5, 10, 15, 30, 50], 
                                   min_dist_range=[0.0, 0.1, 0.25, 0.5, 0.8],
                                   metric='jaccard', random_state=42):
    """
    Подбирает оптимальные параметры UMAP для бинарных данных
    
    Args:
        X: numpy array с бинарными данными
        n_neighbors_range: список значений n_neighbors для перебора
        min_dist_range: список значений min_dist для перебора
        metric: метрика расстояния, для бинарных данных рекомендуется 'jaccard'
        random_state: seed для воспроизводимости результатов
        
    Returns:
        dict: словарь с результатами оптимизации, отсортированный по убыванию silhouette_score
    """
    results = []
    
    for n_neighbors in n_neighbors_range:
        for min_dist in min_dist_range:
            # Применение UMAP с текущими параметрами
            # Можно снижать до 3-х измерений, а не до 2-х.
            reducer = umap.UMAP(
                n_neighbors=n_neighbors, 
                min_dist=min_dist, 
                metric=metric,
                random_state=random_state
            )
            embedding = reducer.fit_transform(X)
            
            # Оценка качества с помощью KMeans и silhouette_score
            # TODO Стоит подумать использовать DBSCAN для подбора оптимальных параметров UMAP - кластеры имеют сильно вытянутую форму
            kmeans = KMeans(n_clusters=3, random_state=random_state, n_init=10)
            labels = kmeans.fit_predict(embedding)
            score = silhouette_score(embedding, labels)
            
            results.append({
                'n_neighbors': n_neighbors,
                'min_dist': min_dist,
                'metric': metric,
                'silhouette_score': score,
                'embedding': embedding,
                'reducer': reducer
            })
            
            print(f"n_neighbors={n_neighbors}, min_dist={min_dist}, metric={metric}, silhouette_score={score:.4f}")
    
    # Сортировка результатов по убыванию silhouette_score
    results.sort(key=lambda x: x['silhouette_score'], reverse=True)
    
    return results

def plot_umap_embedding(embedding, title=None, figsize=(12, 10), point_size=40, alpha=0.7):
    """
    Визуализирует UMAP проекцию данных
    
    Args:
        embedding: numpy array с координатами точек в 2D пространстве
        title: заголовок графика
        figsize: размер фигуры
        point_size: размер точек
        alpha: прозрачность точек
    """
    plt.figure(figsize=figsize)
    scatter = plt.scatter(embedding[:, 0], embedding[:, 1], s=point_size, alpha=alpha, 
                         c=np.arange(len(embedding)), cmap='viridis')
    if title:
        plt.title(title)
    plt.xlabel('UMAP 1')
    plt.ylabel('UMAP 2')
    plt.colorbar(scatter, label='Индекс точки')
    plt.grid(True)
    plt.show()

def find_optimal_clusters(data, max_k=10, random_state=42):
    """
    Определяет оптимальное количество кластеров с помощью метода локтя и силуэтного анализа
    
    Args:
        data: numpy array с данными для кластеризации
        max_k: максимальное количество кластеров для проверки
        random_state: seed для воспроизводимости результатов
        
    Returns:
        tuple: (оптимальное количество кластеров, максимальный силуэтный коэффициент)
    """
    inertia_values = []
    silhouette_scores = []
    
    for k in range(2, max_k + 1):
        kmeans = KMeans(n_clusters=k, random_state=random_state, n_init=10)
        labels = kmeans.fit_predict(data)
        inertia_values.append(kmeans.inertia_)
        silhouette_scores.append(silhouette_score(data, labels))
        print(f"k={k}, inertia={kmeans.inertia_:.2f}, silhouette_score={silhouette_score(data, labels):.4f}")
    
    # Визуализация метода локтя и силуэтного анализа
    plt.figure(figsize=(12, 5))
    
    plt.subplot(1, 2, 1)
    plt.plot(range(2, max_k + 1), inertia_values, 'o-')
    plt.title('Метод локтя для определения оптимального k')
    plt.xlabel('Количество кластеров (k)')
    plt.ylabel('Инерция')
    plt.grid(True)
    
    plt.subplot(1, 2, 2)
    plt.plot(range(2, max_k + 1), silhouette_scores, 'o-')
    plt.title('Силуэтный анализ для определения оптимального k')
    plt.xlabel('Количество кластеров (k)')
    plt.ylabel('Силуэтный коэффициент')
    plt.grid(True)
    
    plt.tight_layout()
    plt.show()
    
    # Возвращаем k с максимальным силуэтным коэффициентом
    optimal_k = silhouette_scores.index(max(silhouette_scores)) + 2
    return optimal_k, max(silhouette_scores)

def plot_clusters(embedding, labels, centroids=None, figsize=(12, 10), title=None):
    """
    Визуализирует результаты кластеризации
    
    Args:
        embedding: numpy array с координатами точек в 2D пространстве
        labels: numpy array с метками кластеров
        centroids: numpy array с координатами центроидов (для K-Means)
        figsize: размер фигуры
        title: заголовок графика
    """
    plt.figure(figsize=figsize)
    scatter = plt.scatter(embedding[:, 0], embedding[:, 1], c=labels, cmap='viridis', s=50, alpha=0.8)
    plt.colorbar(scatter, label='Кластер')
    
    if title:
        plt.title(title)
    else:
        plt.title('Результаты кластеризации')
        
    plt.xlabel('UMAP 1')
    plt.ylabel('UMAP 2')
    plt.grid(True)
    
    # Добавление центроидов кластеров, если они предоставлены
    if centroids is not None:
        plt.scatter(centroids[:, 0], centroids[:, 1], marker='X', s=200, c='red', label='Центроиды')
        plt.legend()
        
    plt.show()

def analyze_cluster_features(df, feature_columns):
    """
    Анализирует характеристики кластеров
    
    Args:
        df: pandas DataFrame с данными и метками кластеров
        feature_columns: список колонок с признаками для анализа
        
    Returns:
        tuple: (средние значения признаков по кластерам, отклонения от общих средних)
    """
    # Вычисление средних значений признаков для каждого кластера
    cluster_means = df.groupby('cluster')[feature_columns].mean()
    
    # Вычисление общих средних значений признаков
    overall_means = df[feature_columns].mean()
    
    # Вычисление отклонений от общих средних
    cluster_deviations = cluster_means - overall_means
    
    return cluster_means, cluster_deviations

def plot_cluster_heatmap(cluster_deviations, figsize=(14, 10), title='Отклонения от общих средних значений признаков по кластерам'):
    """
    Визуализирует отклонения от общих средних значений признаков по кластерам
    
    Args:
        cluster_deviations: pandas DataFrame с отклонениями от общих средних
        figsize: размер фигуры
        title: заголовок графика
    """
    plt.figure(figsize=figsize)
    sns.heatmap(cluster_deviations, cmap='coolwarm', center=0, annot=False)
    plt.title(title)
    plt.tight_layout()
    plt.show()

def optimize_dbscan_for_binary(data, eps_range=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7], 
                              min_samples_range=[3, 5, 10, 15, 20], metric='euclidean'):
    """
    Подбирает оптимальные параметры DBSCAN для данных
    
    Args:
        data: numpy array с данными для кластеризации
        eps_range: список значений eps для перебора
        min_samples_range: список значений min_samples для перебора
        metric: метрика расстояния
        
    Returns:
        list: список словарей с результатами оптимизации, отсортированный по убыванию silhouette_score
    """
    results = []
    
    for eps in eps_range:
        for min_samples in min_samples_range:
            # Применение DBSCAN с текущими параметрами
            dbscan = DBSCAN(eps=eps, min_samples=min_samples, metric=metric)
            labels = dbscan.fit_predict(data)
            
            # Пропускаем случаи, когда все точки отнесены к шуму или к одному кластеру
            n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
            if n_clusters <= 1:
                continue
            
            # Оценка качества с помощью silhouette_score
            # Исключаем точки шума при расчете силуэтного коэффициента
            noise_mask = labels != -1
            if sum(noise_mask) > 1 and len(set(labels[noise_mask])) > 1:
                score = silhouette_score(data[noise_mask], labels[noise_mask])
                noise_percentage = (1 - sum(noise_mask) / len(labels)) * 100
                
                results.append({
                    'eps': eps,
                    'min_samples': min_samples,
                    'metric': metric,
                    'n_clusters': n_clusters,
                    'silhouette_score': score,
                    'noise_percentage': noise_percentage,
                    'labels': labels
                })
                
                print(f"eps={eps}, min_samples={min_samples}, metric={metric}, n_clusters={n_clusters}, "
                      f"silhouette_score={score:.4f}, noise={noise_percentage:.2f}%")
    
    # Сортировка результатов по убыванию silhouette_score
    if results:
        results.sort(key=lambda x: x['silhouette_score'], reverse=True)
        return results
    else:
        print("Не удалось найти подходящие параметры для DBSCAN.")
        return None
