# Утилиты для предобработки данных

import pandas as pd
import numpy as np

def convert_to_binary(df):
    """
    Преобразует данные в бинарный формат
    
    Args:
        df: pandas DataFrame с исходными данными
        
    Returns:
        pandas DataFrame: датафрейм с бинарными данными
    """
    # Создаем копию датафрейма
    df_binary = df.copy()
    
    # Проходим по всем колонкам, кроме ID, Время создания и faculty
    for col in df_binary.columns:
        if col not in ['ID', 'Время создания', 'faculty']:
            # Заполняем пропущенные значения нулями (отсутствие ответа = нет)
            df_binary[col] = df_binary[col].fillna(0)
            
            # Преобразуем в бинарный формат
            # Если в ячейке есть какое-то значение (не NaN и не 0), то 1, иначе 0
            df_binary[col] = df_binary[col].apply(lambda x: 1 if str(x).strip().lower() in ['да', 'yes', '1', 'Moodle', 'moodle'] else 0)
    
    return df_binary

def prepare_data_for_modeling(df_binary):
    """
    Подготавливает данные для моделирования
    
    Args:
        df_binary: pandas DataFrame с бинарными данными
        
    Returns:
        tuple: (матрица признаков, данные о факультетах, список колонок с признаками)
    """
    # Выделение признаков для анализа (исключаем ID, Время создания и faculty)
    feature_columns = [col for col in df_binary.columns if col not in ['ID', 'Время создания', 'faculty']]
    X = df_binary[feature_columns].values
    
    # Сохранение информации о факультетах для последующего анализа (если есть)
    if 'faculty' in df_binary.columns:
        faculty_data = df_binary['faculty']
    else:
        faculty_data = None
    
    return X, faculty_data, feature_columns

def analyze_faculty_distribution(df_with_clusters):
    """
    Анализирует распределение факультетов по кластерам
    
    Args:
        df_with_clusters: pandas DataFrame с данными, метками кластеров и информацией о факультетах
        
    Returns:
        tuple: (кросс-таблица факультет-кластер, нормализованная кросс-таблица)
    """
    if 'faculty' not in df_with_clusters.columns:
        print("Информация о факультетах отсутствует в данных")
        return None, None
    
    # Создание кросс-таблицы факультет-кластер
    faculty_cluster_cross = pd.crosstab(df_with_clusters['faculty'], df_with_clusters['cluster'])
    
    # Нормализация по строкам (доля студентов каждого факультета в каждом кластере)
    faculty_cluster_norm = faculty_cluster_cross.div(faculty_cluster_cross.sum(axis=1), axis=0)
    
    return faculty_cluster_cross, faculty_cluster_norm
