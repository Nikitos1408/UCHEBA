# Утилиты для переименования колонок в более короткие имена

def create_column_mapping(df):
    """
    Создает словарь для переименования колонок в формат q_N
    
    Args:
        df: pandas DataFrame с исходными данными
        
    Returns:
        dict: словарь для переименования колонок {исходное_имя: новое_имя}
    """
    column_mapping = {}
    for i, col in enumerate(df.columns):
        if i < 2:  # Сохраняем ID и Время создания без изменений
            column_mapping[col] = col
        elif 'факультет' in col.lower() or 'институт' in col.lower():
            column_mapping[col] = 'faculty'  # Колонка с факультетом/институтом
        else:
            column_mapping[col] = f'q_{i-2}'  # Остальные колонки переименовываем в q_N
    return column_mapping

def get_original_column_name(short_name, reverse_mapping):
    """
    Получает оригинальное имя колонки по короткому имени
    
    Args:
        short_name: короткое имя колонки (q_N)
        reverse_mapping: обратный словарь {новое_имя: исходное_имя}
        
    Returns:
        str: оригинальное имя колонки или короткое имя, если оригинальное не найдено
    """
    return reverse_mapping.get(short_name, short_name)

def get_top_features_for_cluster(cluster_deviations, cluster_id, reverse_mapping, n=10):
    """
    Получает топ-N наиболее важных признаков для указанного кластера
    
    Args:
        cluster_deviations: DataFrame с отклонениями от средних значений
        cluster_id: идентификатор кластера
        reverse_mapping: обратный словарь {новое_имя: исходное_имя}
        n: количество признаков для вывода
        
    Returns:
        dict: словарь с положительными и отрицательными признаками
    """
    # Сортировка признаков по абсолютному значению отклонения
    sorted_features = cluster_deviations.loc[cluster_id].abs().sort_values(ascending=False)
    
    # Выбор топ-N признаков
    top_n = sorted_features.head(n)
    
    # Сохранение результатов с учетом знака отклонения
    result = {
        'positive': [(feature, cluster_deviations.loc[cluster_id, feature], 
                     get_original_column_name(feature, reverse_mapping)) 
                     for feature in top_n.index if cluster_deviations.loc[cluster_id, feature] > 0],
        'negative': [(feature, cluster_deviations.loc[cluster_id, feature], 
                     get_original_column_name(feature, reverse_mapping)) 
                     for feature in top_n.index if cluster_deviations.loc[cluster_id, feature] < 0]
    }
    
    return result

def print_cluster_features(top_features):
    """
    Выводит информацию о наиболее важных признаках кластера
    
    Args:
        top_features: словарь с положительными и отрицательными признаками
    """
    print("Признаки с положительным отклонением (выше среднего):")
    for feature, value, original_name in top_features['positive']:
        print(f"  {feature}: {value:.4f} - {original_name[:100]}..." 
              if len(original_name) > 100 else f"  {feature}: {value:.4f} - {original_name}")
    
    print("\nПризнаки с отрицательным отклонением (ниже среднего):")
    for feature, value, original_name in top_features['negative']:
        print(f"  {feature}: {value:.4f} - {original_name[:100]}..." 
              if len(original_name) > 100 else f"  {feature}: {value:.4f} - {original_name}")
